package com.luo.materialsystem;

import org.junit.Test;

import java.io.UnsupportedEncodingException;
import java.util.Arrays;

import static org.junit.Assert.*;

/**
 * Example local unit test, which will execute on the development machine (host).
 *
 * @see <a href="http://d.android.com/tools/testing">Testing documentation</a>
 */
public class ExampleUnitTest {
    @Test
    public void addition_isCorrect() {
        assertEquals(4, 2 + 2);
        byte a = 100;
        byte aa = (byte) 0xFF;

        byte[] setPower = new byte[8];
        setPower[0] = 0x0A;
        setPower[1] = (byte) 0xFF;
        setPower[2] = 0x05;
        setPower[3] = 0x23;
        setPower[4] = 0x6F;
        setPower[5] = hexTobytes("1C")[0];
        setPower[6] = hexTobytes("5A")[0];
//        setPower[7] = checkSum(setPower);
        byte[] getPower = new byte[6];
        getPower[0] = 0x0A;
        getPower[1] = (byte) 0xFF;
        getPower[2] = 0x03;
        getPower[3] = 0x24;
        getPower[4] = 0x6F;
//        System.out.println("getPower byte = "+  String.valueOf(checkSum(getPower)));
        //            System.out.println(new String(getPower, "Unicode"));
        getPower[5] = checkSum(getPower);
//        getPower[5] = 0x61;
//        System.out.println(bytesToHexString(getPower));
        String aaa="0bff04000013df";
        byte[] bytes = aaa.getBytes();
//        System.out.println("Decoded String : " + aaa.substring(8,10));
        System.out.println("Decoded String : " +Integer.valueOf( aaa.substring(10,12),16));
//        System.out.println("Decoded String : " + Integer.parseInt(aaa.substring(8,10), 10));

    }

    public byte[] hexTobytes(String hex) {
        byte[] bytes = new byte[hex.length() / 2];
        for (int i = 0; i < hex.length(); i = i + 2) {
            String subStr = hex.substring(i, i + 2);
            boolean flag = false;
            int intH = Integer.parseInt(subStr, 16);
            if (intH > 127) flag = true;
            if (intH == 128) {
                intH = -128;
            } else if (flag) {
                intH = 0 - (intH & 0x7F);
            }
            byte b = (byte) intH;
            bytes[i / 2] = b;
        }
        return bytes;
    }

    private byte checkSum(byte[] data) {
        byte uSum = 0;
        for (int i = 0; i < data.length; i++) {
            uSum = (byte) (uSum + data[i]);
        }
        uSum = (byte) ((~uSum) + 1);
        return uSum;
    }
    public static String bytesToHexString(byte[] src){
        StringBuilder stringBuilder = new StringBuilder("");
        if (src == null || src.length <= 0) {
            return null;
        }
        for (int i = 0; i < src.length; i++) {
            int v = src[i] & 0xFF;
            String hv = Integer.toHexString(v);
            if (hv.length() < 2) {
                stringBuilder.append(0);
            }
            stringBuilder.append(hv);
        }
        return stringBuilder.toString();
    }

}