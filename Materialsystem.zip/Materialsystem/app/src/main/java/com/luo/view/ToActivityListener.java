package com.luo.view;

public interface ToActivityListener {
    void onClickListener(String data);
    void onClickListener(boolean flag);
}