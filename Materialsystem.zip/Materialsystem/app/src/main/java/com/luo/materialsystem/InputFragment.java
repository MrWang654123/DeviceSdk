package com.luo.materialsystem;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Message;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.luo.FileSave.FileTools;
import com.luo.g245.Tools;
import com.luo.scan.Util;
import com.luo.view.All_Adapter;
import com.luo.view.All_Adapter_Iuput;
import com.luo.view.Module;
import com.luo.view.ToActivityListener;
import com.luo.view.ToFragmentListener;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import butterknife.BindView;
import butterknife.ButterKnife;
import jxl.Cell;
import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;

import static android.content.Context.MODE_PRIVATE;

public class InputFragment extends Fragment implements View.OnClickListener, ToFragmentListener {
    @BindView(R.id.listview)
    ListView listView;
    @BindView(R.id.btn_save)
    Button btn_save;
    @BindView(R.id.btn_start)
    Button btn_start;
    @BindView(R.id.et_data)
    EditText et_data;
    @BindView(R.id.cb_filter)
    CheckBox cb_filter;
   @BindView(R.id.iv_clear)
   ImageView iv_clear;

   @BindView(R.id.ll_filter)
    LinearLayout ll_filter;
   @BindView(R.id.btn_clear)
   Button btn_clear;
   @BindView(R.id.btn_input)
   Button btn_input;
   @BindView(R.id.et_count)
   EditText et_count;
   @BindView(R.id.et_count_readed)
   EditText et_count_readed;



    private static String  TAG= "param_home";
    private List<Module> list = new ArrayList<>();
    private Set datas = new HashSet();

    private All_Adapter_Iuput adapter = null;
    private FileTools fileTools;

    private SharedPreferences sp;
    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        sp = getActivity().getSharedPreferences("settings",MODE_PRIVATE);
    }
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_input, container, false);
        ButterKnife.bind(this,root);
        initView();
        fileTools = new FileTools(getActivity());
        return root;
    }
    public static InputFragment newInstance(String str) {
        InputFragment frag = new InputFragment();
        Bundle bundle = new Bundle();
        bundle.putString(TAG, str);
        frag.setArguments(bundle);   //设置参数
        return frag;
    }
    private void initView() {
        btn_start.setOnClickListener(this);
        btn_save.setOnClickListener(this);
        iv_clear.setOnClickListener(this);
        btn_clear.setOnClickListener(this);
        btn_input.setOnClickListener(this);
        adapter = new All_Adapter_Iuput(list,getActivity());
        listView.setAdapter(adapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                et_data.setText(list.get(i).getData()+"");
            }
        });
        cb_filter.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if (b) ll_filter.setVisibility(View.VISIBLE);
                else ll_filter.setVisibility(View.GONE);
            }
        });
    }
    private boolean startFlag = false;
    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.btn_input:
                FilePickerDialog filePickerDialog = new FilePickerDialog(getActivity());
                filePickerDialog.setOnFileSelectListener(new FilePickerDialog.OnFileSelectListener() {
                    @Override
                    public void onFileSelect(File file) {
                        String str = file.getAbsolutePath();
                        if (str.endsWith(".csv")){
                            list = fileTools.readCsv(file);
                        }else if (str.endsWith(".txt")){
                            list = fileTools.readTxt(file);
                        }else if (str.endsWith(".xls")){
                            list = fileTools.readExcel(file);
                        }else {
                            Toast.makeText(getActivity(), "不支持的文件格式！", Toast.LENGTH_SHORT).show();
                            return;
                        }
                        if (list!=null&&list.size()>0) {
                            adapter.setList(list);
                            et_count.setText(list.size()+"");
                            et_count_readed.setText("0");
                        } else
                            Toast.makeText(getActivity(), "未读到数据！", Toast.LENGTH_SHORT).show();
                    }
                });
                filePickerDialog.show();
                break;
            case R.id.btn_start:
                search();
                break;
            case R.id.iv_clear:
                et_data.setText("");
                break;
             case R.id.btn_clear:
                 clear();
                break;
             case R.id.btn_save:
                 if (list==null||list.size()==0) break;
                 dialog();
                break;
        }
    }
    private void clear(){
        list.clear();
        adapter.setList(list);
        et_count.setText(list.size()+"");
        et_count_readed.setText("0");
    }
    private void search() {
        if (sp.getInt("type",1)!=1) {
            if (!startFlag) {
                btn_start.setText("停止");
            } else {
                btn_start.setText("开始");
            }
        }
        toActivityListener.onClickListener(!startFlag);
        startFlag = !startFlag;
    }

    @Override
    public void onDataListener(String data) {
        if (data.equals("--true")){
            search();
            return;
        }else if (data.equals("--false")){
            search();
            return;
        }
        if (cb_filter.isChecked()) {
            if (et_data.getText().toString().equals(data)) {
                Util.play(1, 0);
            }
            return;
        }
        int i = 0;
        for (Module module:list){
            if (module.getFlag().equals("已读")) continue;
            if (module.getData().equals(data)){
                module.setFlag("已读");
                list.set(Integer.parseInt(module.getId())-1,module);
                Log.e("test",i+"");
//                module.toString();
//                datas.add()
                continue;
            }
                i++;
        }
        adapter.setList(list);
        et_count_readed.setText(list.size()-i +"");
    }
    private ToActivityListener toActivityListener;
    public void setToActivityListener(ToActivityListener listener){
        this.toActivityListener = listener;
    }
    private void dialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        View view = LayoutInflater.from(getActivity()).inflate(R.layout.dialog_edittext, null);
        TextView cancel = view.findViewById(R.id.choosepage_cancel);
        TextView sure = view.findViewById(R.id.choosepage_sure);
        final EditText edittext = view.findViewById(R.id.choosepage_edittext);
        final TextView tv_txt = view.findViewById(R.id.tv_txt);
        final TextView tv_csv = view.findViewById(R.id.tv_csv);
        final TextView tv_excel = view.findViewById(R.id.tv_excel);
        if (sp.getBoolean("txt", false))
            tv_txt.setVisibility(View.VISIBLE);
        if (sp.getBoolean("excel", true))
            tv_excel.setVisibility(View.VISIBLE);
        if (sp.getBoolean("csv", false))
            tv_csv.setVisibility(View.VISIBLE);
        edittext.setText(Tools.getTime());
        final Dialog dialog = builder.create();
        dialog.show();
        dialog.getWindow().setContentView(view);
        //使editext可以唤起软键盘
        dialog.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_ALT_FOCUSABLE_IM);
        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        sure.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String filename = edittext.getText().toString();
                boolean saveFlag = false;
                if (sp.getBoolean("txt", false))
                    saveFlag = fileTools.saveTxt2(list, filename);
                if (sp.getBoolean("excel", true))
                    saveFlag = fileTools.saveExcel2(list, filename);
                if (sp.getBoolean("csv", false))
                    saveFlag = fileTools.saveCsv2(list, filename);
                //按下确定键后的事件
                if (saveFlag) {
                    Toast.makeText(getActivity(), "保存成功！", Toast.LENGTH_LONG).show();
                    getActivity().sendBroadcast(new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE, Uri.parse("file://"+ Environment.getExternalStorageDirectory())));
                }else
                    Toast.makeText(getActivity(), "保存失败！", Toast.LENGTH_LONG).show();
                dialog.dismiss();
            }
        });
    }
}
