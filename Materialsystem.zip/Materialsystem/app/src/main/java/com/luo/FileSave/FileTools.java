package com.luo.FileSave;

import android.content.Context;
import android.os.Environment;
import android.support.design.widget.Snackbar;
import android.util.Log;
import android.widget.Toast;

import com.luo.materialsystem.InputFragment;
import com.luo.view.Module;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.ServiceLoader;

import jxl.Cell;
import jxl.Sheet;
import jxl.Workbook;
import jxl.format.Alignment;
import jxl.format.Border;
import jxl.format.BorderLineStyle;
import jxl.format.Colour;
import jxl.read.biff.BiffException;
import jxl.write.Label;
import jxl.write.WritableCellFormat;
import jxl.write.WritableFont;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import jxl.write.WriteException;

public class FileTools {

    public FileTools(Context context) {
        this.mContext = context;
        File file = new File(Environment.getExternalStorageDirectory()+"/MaterialSystem/采集导出/TXT");
        if (!file.exists()) file.mkdirs();
        file = new File(Environment.getExternalStorageDirectory()+"/MaterialSystem/采集导出/CSV");
        if (!file.exists()) file.mkdirs();
        file = new File(Environment.getExternalStorageDirectory()+"/MaterialSystem/采集导出/EXCEL");
        if (!file.exists()) file.mkdirs();
        file = new File(Environment.getExternalStorageDirectory()+"/MaterialSystem/导入盘点/TXT");
        if (!file.exists()) file.mkdirs();
        file = new File(Environment.getExternalStorageDirectory()+"/MaterialSystem/导入盘点/CSV");
        if (!file.exists()) file.mkdirs();
        file = new File(Environment.getExternalStorageDirectory()+"/MaterialSystem/导入盘点/EXCEL");
        if (!file.exists()) file.mkdirs();
        file = new File(Environment.getExternalStorageDirectory()+"/MaterialSystem/导入盘点/电脑导入数据");
        if (!file.exists()) file.mkdirs();

    }
 private Context mContext;
    public ArrayList<Module> readTxt(File file) {
        ArrayList<Module> readerArr = new ArrayList<>();
//        File file = new File(path);
        FileInputStream fileInputStream;
        try {
            fileInputStream = new FileInputStream(file);
            if (fileInputStream != null) {
                InputStreamReader inputreader
                        = new InputStreamReader(fileInputStream, "gb2312");
                BufferedReader buffreader = new BufferedReader(inputreader);
                String line = "";
                int i =1;
                //分行读取
                while ((line = buffreader.readLine()) != null) {
                    line = line.replace("\r","");
                    line = line.replace("\n","");
                    line = line.replace(",","");
                    line = line.replace("，","");
                    readerArr.add(new Module(i+"",line));
                    i++;
                }
                fileInputStream.close();//关闭输入流
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return readerArr;
    }
    public boolean saveTxt (List<Module> listepc, String filename){
        if(listepc==null||listepc.size()<=0) return false;
//        String data = "";
//        for (int i = 0; i < listepc.size(); i++) {
//            data = data +listepc.get(i)+"," + "\r\n";
//        }
        try
        {
//            FileOutputStream outStream = new FileOutputStream(Environment.getExternalStorageDirectory()+"/MaterialSystem/采集导出/TXT/"+filename+".txt",true);
//            OutputStreamWriter writer = new OutputStreamWriter(outStream,"gb2312");
            FileWriter fw = new FileWriter(Environment.getExternalStorageDirectory()+"/MaterialSystem/采集导出/TXT/"+filename+".txt");
            for (int i = 0; i < listepc.size(); i++) {
                fw.write(listepc.get(i).getData()+",\r\n");
            }
            fw.close();
//            writer.write(data);
//            writer.flush();
//            writer.close();//记得关闭
//            outStream.close();
            return true;
        }
        catch (Exception e)
        {
            Log.e("m","txt write error:"  +  e.toString());
            return false;
        }
    }
public boolean saveTxt2 (List<Module> listepc, String filename){
        if(listepc==null||listepc.size()<=0) return false;
//        String data = "";
//        for (int i = 0; i < listepc.size(); i++) {
//            data = data +listepc.get(i)+"," + "\r\n";
//        }
        try
        {
//            FileOutputStream outStream = new FileOutputStream(Environment.getExternalStorageDirectory()+"/MaterialSystem/采集导出/TXT/"+filename+".txt",true);
//            OutputStreamWriter writer = new OutputStreamWriter(outStream,"gb2312");
            FileWriter fw = new FileWriter(Environment.getExternalStorageDirectory()+"/MaterialSystem/导入盘点/TXT/"+filename+".txt");
            for (int i = 0; i < listepc.size(); i++) {
                fw.write(listepc.get(i).getData()+","+listepc.get(i).getFlag()+",\r\n");
            }
            fw.close();
//            writer.write(data);
//            writer.flush();
//            writer.close();//记得关闭
//            outStream.close();
            return true;
        }
        catch (Exception e)
        {
            Log.e("m","txt write error:"  +  e.toString());
            return false;
        }
    }

    public ArrayList<Module> readCsv(File file) {
        ArrayList<Module> readerArr = new ArrayList<>();
//        File file = new File(path);
        FileInputStream fileInputStream;
        Scanner in;
        try {
            fileInputStream = new FileInputStream(file);
            in = new Scanner(fileInputStream, "gb2312");
            in.nextLine();
            while (in.hasNextLine()) {
                String[] lines = in.nextLine().split(",");
                Module bean = new Module(lines[0], lines[1]);
                readerArr.add(bean);
            }
            in.close();
            fileInputStream.close();
        } catch (Exception e) {
            Log.e("m","csv read error:"  +  e.toString());
            e.printStackTrace();
        }
        return readerArr;
    }
    public boolean saveCsv(List<Module> listepc, String filename) {
        try {
            File file = new File(Environment.getExternalStorageDirectory()+"/MaterialSystem/采集导出/CSV/" + filename + ".csv");
            BufferedWriter bw = new BufferedWriter(new FileWriter(file, true));
            // 添加头部名称
//            bw.write("ID" + "," + "DATA" );
            bw.newLine();
            for (int i = 0; i < listepc.size(); i++) {
                bw.write(listepc.get(i).getId() + "," + listepc.get(i).getData());
                bw.newLine();
            }
            bw.close();
            return true;
        } catch (IOException e) {
            e.printStackTrace();
            Log.e("save","csv write error:"  +  e.toString());
            return false;
        }
    }
public boolean saveCsv2(List<Module> listepc, String filename) {
        try {
            File file = new File(Environment.getExternalStorageDirectory()+"/MaterialSystem/导入盘点/CSV/" + filename + ".csv");
            BufferedWriter bw = new BufferedWriter(new FileWriter(file, true));
            // 添加头部名称
//            bw.write("ID" + "," + "DATA" );
            bw.newLine();
            for (int i = 0; i < listepc.size(); i++) {
                bw.write(listepc.get(i).getId() + "," + listepc.get(i).getData()+ "," + listepc.get(i).getFlag());
                bw.newLine();
            }
            bw.close();
            return true;
        } catch (IOException e) {
            e.printStackTrace();
            Log.e("save","csv write error:"  +  e.toString());
            return false;
        }
    }

    public ArrayList<Module> readExcel(File file) {
        ArrayList<Module> readerArr = new ArrayList<>();
//        File file = new File(path);
            try
            {
                FileInputStream file_is = new FileInputStream(file);
                jxl.Workbook jxlworkbook;//定义工作簿
                jxlworkbook = Workbook.getWorkbook(file_is);//获取工作簿
                for (int i=0;i<1;i++){
                    Sheet sheet = jxlworkbook.getSheet(i);//获取qz.xls第0张表单
                    int j = 0;
                    Log.e("lll",sheet.getColumns() + "---" + sheet.getRows());
                    boolean runing = true;
                    while (runing)
                    {
                        try {
                            Cell cell_0 = sheet.getCell(0, j);//获取表单的单元，0列j行
                            Cell cell_1 = sheet.getCell(1, j);//获取表单的单元，0列j行
                            String id = cell_0.getContents().replace(",","").trim();
                            String data = cell_1.getContents().replace(",","").trim();
                            Log.e("EJ-Running","表"+i+"-行"+j+":"+data);
                            Module module =  new Module(id,data);
                            readerArr.add(module);
                            j++;
                        }catch (Exception e){
                            runing = false;
                            Log.e("EJ",sheet.getRows()+"---"+e.toString());
                        }
                    }
                }
                file_is.close();//关闭流
            } catch (BiffException e)
            {
                // TODO Auto-generated catch block
                e.printStackTrace();
                Log.e("Write1 ",e.toString());
            } catch (FileNotFoundException e) {
                e.printStackTrace();
                Log.e("Write2 ",e.toString());

            }catch (IOException e)
            {
                // TODO Auto-generated catch block
                e.printStackTrace();
                Log.e("Write3 ",e.toString());

            }
            return readerArr;
    }
    public boolean saveExcel(List<Module> listepc, String filename) {
        String path = Environment.getExternalStorageDirectory()+"/MaterialSystem/采集导出/EXCEL/"+filename+".xls";
        WritableWorkbook workbook;//
        WritableSheet sheet;//
        try
        {
            File file = new File(path);//
            FileOutputStream os = new FileOutputStream(file);//
            workbook = Workbook.createWorkbook(os);//
            sheet =workbook.createSheet("Data", 0);
//            sheet.addCell(new Label(0, 0, "ID"));//
//            sheet.addCell(new Label(1, 0, "DATA"));

            int i = 0;
            for (Module module:listepc)
            {
                Label label_id = new Label(0, i, module.getId());
                Label label_barcode = new Label(1, i, module.getData());
                sheet.addCell(label_id);
                sheet.addCell(label_barcode);
                i++;
            }
            workbook.write();
            workbook.close();
           return true;
        } catch (Exception e){
            e.toString();
            Log.e("m","excel write error:"  +  e.toString());
            return false;
        }
    }
    public boolean saveExcel2(List<Module> listepc, String filename) {
        String path = Environment.getExternalStorageDirectory()+"/MaterialSystem/导入盘点/EXCEL/"+filename+".xls";
        WritableWorkbook workbook;//
        WritableSheet sheet;//
        try
        {
            File file = new File(path);//
            FileOutputStream os = new FileOutputStream(file);//
            workbook = Workbook.createWorkbook(os);//
            sheet =workbook.createSheet("Data", 0);
//            sheet.addCell(new Label(0, 0, "ID"));//
//            sheet.addCell(new Label(1, 0, "DATA"));

            int i = 0;
            for (Module module:listepc)
            {
                Label label_id = new Label(0, i, module.getId());
                Label label_barcode = new Label(1, i, module.getData());
                Label label_3 = new Label(2, i, module.getFlag());
                sheet.addCell(label_id);
                sheet.addCell(label_barcode);
                sheet.addCell(label_3);
                i++;
            }
            workbook.write();
            workbook.close();
           return true;
        } catch (Exception e){
            e.toString();
            Log.e("m","excel write error:"  +  e.toString());
            return false;
        }
    }

}
