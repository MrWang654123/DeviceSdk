package com.luo.g245;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;


import android.content.Context;
import android.media.AudioAttributes;
import android.media.AudioManager;
import android.media.SoundPool;
import android.os.Build;
import android.util.SparseIntArray;

public class Tools {

	/**
	 * Bytes change to HexString
	 * 
	 * @param b
	 * @param size
	 * @return string
	 */
	public static String Bytes2HexString(byte[] b, int size) {
		String ret = "";
		for (int i = 0; i < size; i++) {
			String hex = Integer.toHexString(b[i] & 0xFF);
			if (hex.length() == 1) {
				hex = "0" + hex;
			}
			ret += hex.toUpperCase(Locale.CHINESE);
		}
		return ret;
	}

	public static byte uniteBytes(byte src0, byte src1) {
		byte _b0 = Byte.decode("0x" + new String(new byte[] { src0 })).byteValue();
		_b0 = (byte) (_b0 << 4);
		byte _b1 = Byte.decode("0x" + new String(new byte[] { src1 })).byteValue();
		byte ret = (byte) (_b0 ^ _b1);
		return ret;
	}

	/**
	 * HexString change to Bytes
	 * 
	 * @param src
	 * @return
	 */
	public static byte[] HexString2Bytes(String src) {
		int len = src.length() / 2;
		byte[] ret = new byte[len];
		byte[] tmp = src.getBytes();

		for (int i = 0; i < len; i++) {
			ret[i] = uniteBytes(tmp[i * 2], tmp[i * 2 + 1]);
		}
		return ret;
	}

	/**
	 * Byte[] change to int
	 * 
	 * @param bytes
	 * @return int
	 */
	public static int bytesToInt(byte[] bytes) {
		int addr = bytes[0] & 0xFF;
		addr |= ((bytes[1] << 8) & 0xFF00);
		addr |= ((bytes[2] << 16) & 0xFF0000);
		addr |= ((bytes[3] << 25) & 0xFF000000);
		return addr;
	}
		public static String bytesToIntFor245(byte[] bytes) {
		int type = (bytes[0] >>2)&0x3F;
		int manufacturer = (((bytes[1]& 0xE0)>>5))&0xFF + ((bytes[0]&0x03)<<3)&0xFF;
		int batch = (((bytes[2]&0xFC)>>2)&0xFF)|((bytes[1]& 0x1F)<<6) &0xFFFF;
		int item = (bytes[3] & 0xFF)|(((bytes[2]&0x03) << 8)&0xFF00);
		String types = type+"";
		switch (types.length()){
			case 1:
				types = "0" + types;
				break;
		}
		String manufacturers = manufacturer +"";
			switch (manufacturers.length()){
				case 1:
					manufacturers = "0" + manufacturers;
					break;
			}
		String batchs = batch +"";
			switch (batchs.length()){
				case 1:
					batchs = "000" + batchs;
					break;
				case 2:
					batchs = "00" + batchs;
					break;
				case 3:
					batchs = "0" + batchs;
					break;

			}
		String items = item+"";
			switch (items.length()){
				case 1:
					items = "000" + items;
					break;
				case 2:
					items = "00" + items;
					break;
				case 3:
					items = "0" + items;
					break;

			}
		return types + "" +manufacturers+"" + batchs + ""+items;
	}

	/**
	 * Int change to byte[]
	 * 
	 * @param i
	 * @return byte[]
	 */
	public static byte[] intToByte(int i) {
		byte[] abyte0 = new byte[4];
		abyte0[0] = (byte) (0xff & i);
		abyte0[1] = (byte) ((0xff00 & i) >> 8);
		abyte0[2] = (byte) ((0xff0000 & i) >> 16);
		abyte0[3] = (byte) ((0xff000000 & i) >> 24);
		return abyte0;
	}

	/**
	 * System time now (Format:yyyy-MM-dd HH:mm:ss)
	 * 
	 * @return string
	 */
	public static String getTime() {
		String model = "yyyy-MM-dd-HH-mm-ss";
		Date date = new Date();
		SimpleDateFormat format = new SimpleDateFormat(model, Locale.CHINESE);
		String dateTime = format.format(date);
		return dateTime;
	}

//	private static SoundPool sp;
//	private static SparseIntArray suondMap;
//	private static Context mContext;
//	private static AudioManager sAudioManager;
//
//	// 初始化声音池
//	@SuppressWarnings("deprecation")
//	public static void initTools(Context context) {
//		if (Build.VERSION.SDK_INT >= 21) {
//			sp = new SoundPool.Builder().setMaxStreams(2)
//					.setAudioAttributes(
//							new AudioAttributes.Builder().setLegacyStreamType(AudioManager.STREAM_MUSIC).build())
//					.build();
//		} else {
//			// This old constructor is deprecated, but we need it for
//			// compatibility.
//			sp = new SoundPool(2, AudioManager.STREAM_MUSIC, 0);
//		}
//		mContext = context;
//		suondMap = new SparseIntArray(5);
//		suondMap.put(1, sp.load(context, R.raw.msg, 1));
//		sAudioManager = (AudioManager) mContext.getSystemService(Context.AUDIO_SERVICE);
//		// 返回当前AlarmManager最大音量
//		int audioMaxVolume = sAudioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
//		sAudioManager.setStreamVolume(AudioManager.STREAM_MUSIC, audioMaxVolume, AudioManager.FLAG_PLAY_SOUND);
//	}
//
//	// 播放声音池声音
//	public static void play(int sound, int number) {
//		// 返回当前AudioManager对象的音量值
//		float audioCurrentVolume = sAudioManager.getStreamVolume(AudioManager.STREAM_MUSIC);
//		// float volumnRatio = audioCurrentVolume/audioMaxVolume;
//		sp.play(suondMap.get(sound), // 播放的音乐Id
//				audioCurrentVolume, // 左声道音量
//				audioCurrentVolume, // 右声道音量
//				1, // 优先级，0为最低
//				number, // 循环次数，0无不循环，-1无永远循环
//				1);// 回放速度，值在0.5-2.0之间，1为正常速度
//	}

}
