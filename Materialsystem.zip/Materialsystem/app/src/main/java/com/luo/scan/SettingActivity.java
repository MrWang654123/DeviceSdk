//package com.luo.scan;
//
//import java.util.ArrayList;
//import java.util.List;
//
//import cn.pda.serialport.SerialPort;
//
//import android.app.Activity;
//import android.content.Context;
//import android.content.Intent;
//import android.content.SharedPreferences;
//import android.content.SharedPreferences.Editor;
//import android.os.Bundle;
//import android.view.View;
//import android.view.View.OnClickListener;
//import android.widget.AdapterView;
//import android.widget.ArrayAdapter;
//import android.widget.Button;
//import android.widget.Spinner;
//import android.widget.TextView;
//import android.widget.Toast;
//import android.widget.AdapterView.OnItemSelectedListener;
//
//public class SettingActivity extends Activity {
//	private Spinner spinnerSerialport ;
//	private Spinner spinnerBuadrate ;
//	private Spinner spinnerPower ;
//	private Button buttonSet ;
//	private TextView textTips ;
//	private String[] buadrateStrs ;
//	private String[] serialportStrs ;
//	private String[] powerStrs ;
//
//	private List<String> listBuadRate;
//	private List<String> listSerialPort;
//	private List<String> listPower;
//	private int port = 0;
//	private int buad = 9600;
//	private int power = 2 ;
//	@Override
//	protected void onCreate(Bundle savedInstanceState) {
//		super.onCreate(savedInstanceState);
//		setContentView(R.layout.activity_setting);
//
//		initView();
//	}
//
//	private void initView() {
//		textTips = (TextView) findViewById(R.id.textSettingTips);
//		spinnerSerialport = (Spinner) findViewById(R.id.spinnerSerialport);
//		spinnerBuadrate = (Spinner) findViewById(R.id.spinnerBuadrate);
//		spinnerPower = (Spinner) findViewById(R.id.spinnerPower);
//		buttonSet = (Button) findViewById(R.id.buttonOpen);
//
//		buadrateStrs = getResources().getStringArray(R.array.buadrateArray);
//		serialportStrs = getResources().getStringArray(R.array.serialportArray);
//		powerStrs =getResources().getStringArray(R.array.powerArray);
//		listBuadRate = new ArrayList<String>();
//		listSerialPort = new ArrayList<String>();
//		listPower = new ArrayList<String>();
//
//		for(String buad:buadrateStrs){
//			listBuadRate.add(buad);
//		}
//		for(String serial:serialportStrs){
//			listSerialPort.add(serial);
//		}
//		for(String power:powerStrs){
//			listPower.add(power);
//		}
//
//		spinnerBuadrate.setAdapter(new ArrayAdapter<String>(this,
//				android.R.layout.simple_spinner_dropdown_item,
//				listBuadRate));
//		spinnerSerialport.setAdapter(new ArrayAdapter<String>(this,
//				android.R.layout.simple_spinner_dropdown_item,
//				listSerialPort));
//		spinnerPower.setAdapter(new ArrayAdapter<String>(this,
//				android.R.layout.simple_spinner_dropdown_item,
//				listPower));
//		listener();
//
//
//	}
//
//
//	@Override
//	protected void onResume() {
//		SharedPreferences preference = getSharedPreferences("serialport", Context.MODE_PRIVATE);
//		String powerString = "";
//		switch (preference.getInt("power", 2)) {
//		case SerialPort.Power_3v3:
//			powerString = "power_3V3";
//			break;
//		case SerialPort.Power_5v:
//			powerString = "power_5V";
//			break;
//		case SerialPort.Power_Scaner:
//			powerString = "scan_power";
//			break;
//		case SerialPort.Power_Psam:
//			powerString = "psam_power";
//			break;
//		case SerialPort.Power_Rfid:
//			powerString = "rfid_power";
//			break;
//		default:
//			break;
//		};
//		textTips.setText(
//				"Current: Port: com"+  preference.getInt("port", 0) + ";" +
//				"Buadrate: " + preference.getInt("buadrate", 9600)+ ";" +
//				"Power: " + powerString);
//		super.onResume();
//	}
//	private void listener (){
//		spinnerSerialport.setOnItemSelectedListener(new OnItemSelectedListener() {
//
//			@Override
//			public void onItemSelected(AdapterView<?> adapter, View view,
//					int position, long id) {
//				port = position;
//			}
//
//			@Override
//			public void onNothingSelected(AdapterView<?> arg0) {
//			}
//		});
//		spinnerBuadrate.setOnItemSelectedListener(new OnItemSelectedListener() {
//
//			@Override
//			public void onItemSelected(AdapterView<?> adapter, View view,
//					int position, long id) {
//				String buadrate = buadrateStrs[position];
//				buad = Integer.valueOf(buadrate);
//			}
//
//			@Override
//			public void onNothingSelected(AdapterView<?> arg0) {
//
//			}
//		});
//		spinnerPower.setOnItemSelectedListener(new OnItemSelectedListener() {
//
//			@Override
//			public void onItemSelected(AdapterView<?> adapter, View view,
//					int position, long id) {
//				power = position;
//			}
//
//			@Override
//			public void onNothingSelected(AdapterView<?> arg0) {
//
//			}
//		});
//
//		buttonSet.setOnClickListener(new OnClickListener() {
//
//			@Override
//			public void onClick(View v) {
//
//				SharedPreferences preference = getSharedPreferences("serialport", Context.MODE_PRIVATE);
//				Editor editor = preference.edit();
//				editor.putInt("port", port);
//				editor.putInt("buadrate", buad);
//				editor.putInt("power", power);
//				editor.commit();
//				Toast.makeText(getApplicationContext(), "setting success", 0).show();
//				Intent intent = new Intent(SettingActivity.this, MainActivity.class);
//				Bundle bundle = new Bundle();
//				bundle.putInt("port", port);
//				bundle.putInt("buadrate", buad);
//				bundle.putInt("power", power);
//				intent.putExtras(bundle);
//				setResult(RESULT_OK, intent);
//				finish();
//			}
//		});
//	}
//
//	public static final int RESULT_OK = 1001;
//}
