package com.luo.materialsystem;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.luo.FileSave.FileTools;
import com.luo.g245.Tools;
import com.luo.view.All_Adapter;
import com.luo.view.Module;
import com.luo.view.ToActivityListener;
import com.luo.view.ToFragmentListener;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import butterknife.BindView;
import butterknife.ButterKnife;

import static android.content.Context.MODE_PRIVATE;

public class HomeFragment extends Fragment implements View.OnClickListener , ToFragmentListener {
    @BindView(R.id.listview)
    ListView listView;
    @BindView(R.id.btn_save)
    Button btn_save;
    @BindView(R.id.btn_start)
    Button btn_start;
    @BindView(R.id.btn_clear)
    Button btn_clear;
    @BindView(R.id.et_count)
    EditText et_count;


    private static String  TAG= "param_home";
    private List<Module> list = new ArrayList<>();
    private Set datas = new HashSet();

    private All_Adapter adapter = null;
    private FileTools fileTools;
    public static HomeFragment newInstance(String str) {
        HomeFragment frag = new HomeFragment();
        Bundle bundle = new Bundle();
        bundle.putString(TAG, str);
        frag.setArguments(bundle);   //设置参数
        return frag;
    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_home, container, false);
        ButterKnife.bind(this,root);
        initView();
        fileTools = new FileTools(getActivity());
        return root;
    }

    private SharedPreferences sp;
    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        sp = getActivity().getSharedPreferences("settings",MODE_PRIVATE);
    }

    private void initView() {
         btn_start.setOnClickListener(this);
        btn_save.setOnClickListener(this);
        btn_clear.setOnClickListener(this);
        adapter = new All_Adapter(list,getActivity());
        listView.setAdapter(adapter);
    }
    private boolean startFlag = false;
    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.btn_save:
                if (list.size()==0) return;
                dialog();
                break;
            case R.id.btn_start:
                search();
                break;
            case R.id.btn_clear:
                clear();
                break;

        }
    }

    private void clear() {
        list.clear();
        datas.clear();
        adapter.setList(list);
        et_count.setText(list.size()+"");
    }

    private void search() {
        if (sp.getInt("type",1)!=1) {
            if (!startFlag) {
                btn_start.setText("停止");
            } else {
                btn_start.setText("开始");
            }
        }
        toActivityListener.onClickListener(!startFlag);
        startFlag = !startFlag;
    }

    @Override
    public void onDataListener(String data) {
        if (data.equals("--true")){
            search();
            return;
        }else if (data.equals("--false")){
            search();
            return;
        }
        if (datas.contains(data)) return;
        Module module = new Module(list.size()+ 1 +"",data);
        list.add(module);
        datas.add(data);
        adapter.setList(list);
        et_count.setText(list.size()+"");
    }
    private  ToActivityListener toActivityListener;
    public void setToActivityListener(ToActivityListener listener){
        this.toActivityListener = listener;
    }
    private void dialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        View view = LayoutInflater.from(getActivity()).inflate(R.layout.dialog_edittext, null);
        TextView cancel = view.findViewById(R.id.choosepage_cancel);
        TextView sure = view.findViewById(R.id.choosepage_sure);
        final EditText edittext = view.findViewById(R.id.choosepage_edittext);
        final TextView tv_txt = view.findViewById(R.id.tv_txt);
        final TextView tv_csv = view.findViewById(R.id.tv_csv);
        final TextView tv_excel = view.findViewById(R.id.tv_excel);
        if (sp.getBoolean("txt", false))
            tv_txt.setVisibility(View.VISIBLE);
        if (sp.getBoolean("excel", true))
            tv_excel.setVisibility(View.VISIBLE);
        if (sp.getBoolean("csv", false))
            tv_csv.setVisibility(View.VISIBLE);
        edittext.setText(Tools.getTime());
        final Dialog dialog = builder.create();
        dialog.show();
        dialog.getWindow().setContentView(view);
        //使editext可以唤起软键盘
        dialog.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_ALT_FOCUSABLE_IM);
        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        sure.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String filename = edittext.getText().toString();
                boolean saveFlag = false;
                if (sp.getBoolean("txt", false))
                    saveFlag = fileTools.saveTxt(list, filename);
                if (sp.getBoolean("excel", true))
                    saveFlag = fileTools.saveExcel(list, filename);
                if (sp.getBoolean("csv", false))
                    saveFlag = fileTools.saveCsv(list, filename);
                //按下确定键后的事件
                if (saveFlag) {
                    Toast.makeText(getActivity(), "保存成功！", Toast.LENGTH_LONG).show();
                    clear();
                    getActivity().sendBroadcast(new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE, Uri.parse("file://"+ Environment.getExternalStorageDirectory())));
                }else
                    Toast.makeText(getActivity(), "保存失败！", Toast.LENGTH_LONG).show();
                dialog.dismiss();
            }
        });
    }
}
