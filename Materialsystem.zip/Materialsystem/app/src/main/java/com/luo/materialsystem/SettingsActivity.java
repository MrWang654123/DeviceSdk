package com.luo.materialsystem;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class SettingsActivity extends AppCompatActivity implements CompoundButton.OnCheckedChangeListener {
    @BindView(R.id.rg_type)
    RadioGroup rg_type;
    @BindView(R.id.rbscan)
    RadioButton rbscan;
    @BindView(R.id.rbuhf)
    RadioButton rbuhf;
    @BindView(R.id.rb245)
    RadioButton rb245;

    @BindView(R.id.cb_excel)
    CheckBox cb_excel;
    @BindView(R.id.cb_csv)
    CheckBox cb_csv;
    @BindView(R.id.cb_txt)
    CheckBox cb_txt;
    @BindView(R.id.cb_f1)
    CheckBox cb_f1;
    @BindView(R.id.cb_f2)
    CheckBox cb_f2;
    @BindView(R.id.cb_f3)
    CheckBox cb_f3;
    @BindView(R.id.cb_f4)
    CheckBox cb_f4;
    @BindView(R.id.spuhf)
    Spinner spuhf;
    @BindView(R.id.spuhf2)
    Spinner spuhf2;


    SharedPreferences sp;
    SharedPreferences.Editor editor;
    @BindView(R.id.btn_get_power)
    Button btnGetPower;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
        ButterKnife.bind(this);
        initData();
        initListener();
    }

    private void initData() {
        sp = getSharedPreferences("settings", MODE_PRIVATE);
        editor = sp.edit();
        int type = sp.getInt("type", 1);
        switch (type) {
            case 1:
                rbscan.setChecked(true);
                break;
            case 2:
                rbuhf.setChecked(true);
                break;
            case 3:
                rb245.setChecked(true);
                break;
        }
        cb_csv.setChecked(sp.getBoolean("csv", false));
        cb_excel.setChecked(sp.getBoolean("excel", true));
        cb_txt.setChecked(sp.getBoolean("txt", false));
        cb_f1.setChecked(sp.getBoolean("f1", false));
        cb_f2.setChecked(sp.getBoolean("f2", false));
        cb_f3.setChecked(sp.getBoolean("f3", false));
        cb_f4.setChecked(sp.getBoolean("f4", false));
        spuhf.setSelection(sp.getInt("power", 30), true);
//        spuhf2.setSelection(sp.getInt("power", 100), true);
    }

    private void initListener() {
        cb_csv.setOnCheckedChangeListener(this);
        cb_excel.setOnCheckedChangeListener(this);
        cb_txt.setOnCheckedChangeListener(this);
        cb_f1.setOnCheckedChangeListener(this);
        cb_f2.setOnCheckedChangeListener(this);
        cb_f3.setOnCheckedChangeListener(this);
        cb_f4.setOnCheckedChangeListener(this);
        rg_type.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int id) {
                switch (id) {
                    case R.id.rbscan:
                        editor.putInt("type", 1);
                        break;
                    case R.id.rbuhf:
                        editor.putInt("type", 2);
                        break;
                    case R.id.rb245:
                        editor.putInt("type", 3);
                        break;
                }
                editor.commit();
            }
        });
        spuhf.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                editor.putInt("power", i);
                editor.commit();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
        spuhf2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                editor.putInt("power_2", i);
                editor.commit();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
    }


    @Override
    public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
        switch (compoundButton.getId()) {
            case R.id.cb_excel:
                editor.putBoolean("excel", b);
                break;
            case R.id.cb_csv:
                editor.putBoolean("csv", b);
                break;
            case R.id.cb_txt:
                editor.putBoolean("txt", b);
                break;
            case R.id.cb_f1:
                editor.putBoolean("f1", b);
                break;
            case R.id.cb_f2:
                editor.putBoolean("f2", b);
                break;
            case R.id.cb_f3:
                editor.putBoolean("f3", b);
                break;
            case R.id.cb_f4:
                editor.putBoolean("f4", b);
                break;
        }
        editor.commit();
    }

    @OnClick(R.id.btn_get_power)
    public void onViewClicked() {
        
    }
}
