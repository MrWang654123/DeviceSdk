package com.luo.materialsystem;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.luo.g245.Tools;
import com.luo.g245.TpfManager;
import com.luo.scan.ScanThread;
import com.luo.scan.Util;
import com.luo.view.ToActivityListener;
import com.uhf.scanlable.UHFLib;
import com.uhf.scanlable.UHfData;
import com.uhf.scanlable.UHfData.UHfGetData;

import java.io.IOException;
import java.lang.ref.WeakReference;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;


public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    @BindView(R.id.tv_title)
    TextView mTextMessage;
    @BindView(R.id.tv_title_tip)
    TextView tv_title_tip;
    @BindView(R.id.iv_settings)
    ImageView iv_settings;
    private String devport = "/dev/ttyMT1";
    private int MESSAGE_SUCCESS = 0;
    private int MESSAGE_FAIL = 1;
    private HomeFragment homeFragment;
    private InputFragment inputFragment;
    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {


            FragmentTransaction ft = fm.beginTransaction();
            switch (item.getItemId()) {
                case R.id.navigation_home:
                    mTextMessage.setText(R.string.title_home);
                    ft.hide(nowFrag);
                    nowFrag = fm.findFragmentByTag("home");
                    ft.show(nowFrag);
                    ft.commit();
                    return true;
                case R.id.navigation_dashboard:
                    mTextMessage.setText(R.string.title_dashboard);
                    ft.hide(nowFrag);
                    nowFrag = fm.findFragmentByTag("input");
                    ft.show(nowFrag);
                    ft.commit();
                    return true;
//                case R.id.navigation_notifications:
//                    mTextMessage.setText(R.string.title_notifications);
//                    return true;
            }
            return false;
        }
    };
    //    private void initTitlebaar(){
//            View decorView = getWindow().getDecorView();
//            decorView.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
//            getWindow().setStatusBarColor(Color.TRANSPARENT);
//    }
    private SharedPreferences sp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        UHFLib a = UHfData.UHfGetData.getUhf();
        Log.d("aaaa", a+"");
        sp = getSharedPreferences("settings", MODE_PRIVATE);
        ButterKnife.bind(this);
        BottomNavigationView navView = findViewById(R.id.nav_view);
        navView.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);
        initView();
        Util.initSoundPool(MainActivity.this);
    }

    @Override
    protected void onResume() {
        super.onResume();
        rfidType = sp.getInt("type", 1);
        intRfid();
        setReceiver();
        UHFLib a = UHfData.UHfGetData.getUhf();
        Log.d("aaaa", a+"");
    }

    @Override
    protected void onPause() {
        super.onPause();
        closeRfid();
        unregisterReceiver(receiver);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    private void closeRfid() {
        switch (rfidType) {
            case 1:
                scanThread.close();
                break;
            case 3:
                mTpfManager.closePortPower();
                break;
        }
        runFlag = false;
        search(false);
    }

    private int rfidType = 3;//1 scan 3 2.45G 2 uhf
    private static ScanThread scanThread;
    private TpfManager mTpfManager;
    //    private UHFReader uhfReader;
    private ReadThread mReadThread;

    @Override
    protected void onStart() {
        new Thread(new Runnable() {
            public void run() {
                try {
                    int result = UHfGetData.OpenUHf(devport, 57600);
                    if (result == 0) {
                        Thread.sleep(200);
                        int i = UHfGetData.GetUhfInfo();
                        int setResult = UHfGetData.SetRfPower((byte) 19);

                        byte uhfPower = UHfGetData.getUhfdBm()[0];

                        Log.i("Huang, MainActivity", "GetUhfInfo: " + i + uhfPower + setResult);
                        if (i == 0) {
                            mHandler.sendEmptyMessage(MESSAGE_SUCCESS);
                        } else {
                            mHandler.sendEmptyMessage(MESSAGE_FAIL);
                        }
                    } else {
                        mHandler.sendEmptyMessage(MESSAGE_FAIL);
                    }
                } catch (Exception e) {
                    mHandler.sendEmptyMessage(MESSAGE_FAIL);
                }
            }
        }).start();
        super.onStart();
    }

    @Override
    protected void onStop() {
        UHfGetData.CloseUHf();
        super.onStop();
    }


    private void intRfid() {
        runFlag = true;
        switch (rfidType) {
            case 1:
                try {
                    scanThread = new ScanThread(mHandler);
                    scanThread.start();
                } catch (IOException e) {
                    e.printStackTrace();
                    Log.e("error ", e.toString());
                    tv_title_tip.setText("error");
                    return;
                }
                tv_title_tip.setText("扫码");
                break;
            case 3:
                mTpfManager = TpfManager.getInstance();
                mTpfManager.openPortPower();
                mTpfManager.setPower(sp.getInt("power_2", 15));
                if (mTpfManager != null) {
                    mReadThread = new ReadThread();
                    mReadThread.start();
                    tv_title_tip.setText("2.4G");
                }
                break;
            case 2:
                int result = UHfGetData.OpenUHf("/dev/ttyMT1", 57600);
                if (result == 0) {
//                    UHfGetData.SetRfPower((byte) sp.getInt("power", 30));
//                    byte aa = UHfGetData.getUhfdBm()[0];
//                    Log.d("power","uhf-->"+aa);
                    tv_title_tip.setText("超高频");
                    mReadThread = new ReadThread();
                    mReadThread.start();
                }
                break;
        }
    }

    public static String bytesToHexString(byte[] src) {
        StringBuilder stringBuilder = new StringBuilder("");
        if (src == null || src.length <= 0) {
            return null;
        }
        for (int i = 0; i < src.length; i++) {
            int v = src[i] & 0xFF;
            String hv = Integer.toHexString(v);
            if (hv.length() < 2) {
                stringBuilder.append(0);
            }
            stringBuilder.append(hv);
        }
        return stringBuilder.toString();
    }

    private FragmentManager fm;
    private Fragment nowFrag;

    private void initView() {
        iv_settings.setOnClickListener(this);
        tv_title_tip.setOnClickListener(this);
        homeFragment = HomeFragment.newInstance("home");
        homeFragment.setToActivityListener(new ToActivityListener() {
            @Override
            public void onClickListener(String data) {

            }

            @Override
            public void onClickListener(boolean flag) {
                search(flag);
            }
        });
        inputFragment = InputFragment.newInstance("input");
        inputFragment.setToActivityListener(new ToActivityListener() {
            @Override
            public void onClickListener(String data) {

            }

            @Override
            public void onClickListener(boolean flag) {
                search(flag);
            }
        });
        fm = getSupportFragmentManager();
        FragmentTransaction ft = fm.beginTransaction();
        ft.add(R.id.fl_frag_main, inputFragment, "input");
        ft.hide(inputFragment);
        ft.add(R.id.fl_frag_main, homeFragment, "home");
        ft.show(homeFragment);
        ft.commit();
        nowFrag = homeFragment;
    }

    private void search(boolean flag) {
        switch (rfidType) {
            case 1:
                scanThread.scan();
                break;
            case 3:
                mTpfManager.activeTagsInventory();
                startFrag = flag;
                break;
            case 2:
                new UHfData(MainActivity.this);
                startFrag = flag;
                break;

        }
    }

    private void setReceiver() {
        receiver = new KeyReceiver();
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction("android.rfid.FUN_KEY");
        registerReceiver(receiver, intentFilter);
    }

    private int fileCount;
    private int barcodeCount = 0;
    private KeyReceiver receiver;

    private String dateFile;

    private Handler mHandler = new Handler() {
        public void handleMessage(Message msg) {
            if (msg.what == 100) {
                String data = msg.getData().getString("data");
                if (nowFrag == homeFragment)
                    homeFragment.onDataListener(data);
                else
                    inputFragment.onDataListener(data);
            }
            if (msg.what == MESSAGE_SUCCESS) {
                Toast.makeText(MainActivity.this, "success",
                        Toast.LENGTH_SHORT).show();
            } else if (msg.what == MESSAGE_FAIL) {
                Toast.makeText(MainActivity.this, "failed",
                        Toast.LENGTH_SHORT).show();
            }
            super.handleMessage(msg);
        }
    };

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.tv_title_tip:
//                mTpfManager.getPower();
                break;
            case R.id.iv_settings:
                // 60 需要很近
//                if (mTpfManager.setPower(60)) {
//                    Toast.makeText(this,"设置成功 ",1).show();
//                }else{
//                    Toast.makeText(this,"失败，重设 ",1).show();
//
//                }
//                mTpfManager.getPower();

                startActivity(new Intent(MainActivity.this, SettingsActivity.class));
                break;

        }
    }


    class KeyReceiver extends BroadcastReceiver {
        private String TAG = "KeyReceiver";

        @Override
        public void onReceive(Context context, Intent intent) {
            int keyCode = intent.getIntExtra("keyCode", 0);
            if (keyCode == 0) {//兼容H941
                keyCode = intent.getIntExtra("keycode", 0);
            }
            boolean keyDown = intent.getBooleanExtra("keydown", false);
            if (!keyDown) {
                switch (keyCode) {
                    case KeyEvent.KEYCODE_F1:
                        if (sp.getBoolean("f1", false)) {
                            if (nowFrag == homeFragment)
                                homeFragment.onDataListener("--true");
                            else
                                inputFragment.onDataListener("--true");
                        }
                        break;
                    case KeyEvent.KEYCODE_F2:
                        if (sp.getBoolean("f2", false)) {
                            if (nowFrag == homeFragment)
                                homeFragment.onDataListener("--true");
                            else
                                inputFragment.onDataListener("--true");
                        }
                        break;
                    case KeyEvent.KEYCODE_F3:
                        if (sp.getBoolean("f3", false)) {
                            if (nowFrag == homeFragment)
                                homeFragment.onDataListener("--true");
                            else
                                inputFragment.onDataListener("--true");
                        }
                        break;
                    case KeyEvent.KEYCODE_F4:
                        if (sp.getBoolean("f4", false)) {
                            if (nowFrag == homeFragment)
                                homeFragment.onDataListener("--true");
                            else
                                inputFragment.onDataListener("--true");
                        }
                        break;
                    case KeyEvent.KEYCODE_F5:
                        if (sp.getBoolean("f4", false)) {
                            if (nowFrag == homeFragment)
                                homeFragment.onDataListener("--true");
                            else
                                inputFragment.onDataListener("--true");
                        }
                        break;
                }
            }
        }
    }

    private boolean runFlag = true;
    private boolean startFrag = false;

    private class ReadThread extends Thread {
        @Override
        public void run() {
            super.run();
            while (runFlag) {
                if (startFrag) {
                    switch (rfidType) {
                        case 3:
                            List<byte[]> tagList = mTpfManager.activeGetData();
                            if (tagList != null && tagList.size() > 0) {
                                for (byte[] bs : tagList) {
                                    sendMessege(bs);
                                }
                            }
                            continue;
                        case 2:
                            UHfData.Inventory_6c(0, 0);
                            List<UHfData.InventoryTagMap> data = UHfData.lsTagList;
                            for (UHfData.InventoryTagMap d : data) {
                                sendUHFMessege(d.strEPC);
                            }
                            UHfData.lsTagList.clear();
                            UHfData.dtIndexMap.clear();
                            continue;
                    }
                }
                try {
                    Thread.sleep(20);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }

            }
        }
    }

    private void sendMessege(byte[] data) {
        String dataStr = Tools.bytesToIntFor245(data);
        Bundle bundle = new Bundle();
        bundle.putString("data", dataStr);
        Message msg = new Message();
        msg.what = 100;
        msg.setData(bundle);
        mHandler.sendMessage(msg);
    }

    private void sendUHFMessege(String dataStr) {
        Bundle bundle = new Bundle();
        bundle.putString("data", dataStr);
        Message msg = new Message();
        msg.what = 100;
        msg.setData(bundle);
        mHandler.sendMessage(msg);
    }
}
