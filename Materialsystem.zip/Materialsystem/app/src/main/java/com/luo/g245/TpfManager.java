package com.luo.g245;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import android.util.Log;

import cn.pda.serialport.SerialPort;

public class TpfManager {
    /**
     * Port Com
     */
    private static final int PORT = 14;
    private SerialPort mSerialPort;
    private OutputStream mOutputStream;
    private InputStream mInputStream;

    private static TpfManager mTpfManager;

    private TpfManager() {

    }

    public static TpfManager getInstance() {
        if (mTpfManager == null) {
            mTpfManager = new TpfManager();
        }
        return mTpfManager;
    }

    /**
     * Open module's port and power
     *
     * @return exec result
     */
    public boolean openPortPower() {
        try {
            mSerialPort = new SerialPort(PORT, 115200, 0);
        } catch (Exception e) {
            Log.e("Huang", "openPortPower >>>>>> ERROR : \n" + e.getMessage());
            e.printStackTrace();
            return false;
        }
        if (mSerialPort == null) {
            Log.e("Huang", "openPortPower >>>>>> ERROR : \nport is not exit");
            return false;
        }
        mSerialPort.power_3v3on();
        mOutputStream = mSerialPort.getOutputStream();
        mInputStream = mSerialPort.getInputStream();
        byte[] buffer = new byte[1024];
        try {
            Thread.sleep(100);
            int len = mInputStream.read(buffer);
            String respone = new String(buffer, 0, len, "UTF-8");
            Log.v("Huang", "openPortPower respone : \n" + respone);
        } catch (Exception e) {
            Log.e("Huang", "openPortPower >>>>>> ERROR : \nport is not available");
            e.printStackTrace();
        }
        return true;
    }

    /**
     * Close module's port and power
     *
     * @return exec result
     */
    public boolean closePortPower() {
        try {
            mInputStream.close();
            mOutputStream.close();
        } catch (IOException e) {
            Log.e("Huang", "closePortPower >>>>>> ERROR : \n" + e.getMessage());
            e.printStackTrace();
            return false;
        }
        mSerialPort.power_3v3off();
        mSerialPort.close(PORT);
        return true;
    }

    public void get234Power() {
        byte[] getPower = new byte[6];
        getPower[0] = 0x0A;
        getPower[1] = (byte) 0xFF;
        getPower[2] = 0x03;
        getPower[3] = 0x24;
        getPower[4] = 0x6F;
        getPower[5] = checkSum(getPower);
//        getPower[5] = 0x61;
        try {
            Log.d("getPower send-- ", bytesToHexString(getPower));

            mOutputStream.write(getPower);
            byte[] cache = new byte[7];
            Thread.sleep(10);
            mInputStream.read(cache);
//            Log.d("getPower error=== ", Arrays.toString(cache));
            Log.d("getPower -- ", bytesToHexString(cache));
        } catch (IOException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    int repeatTime = 0;
    int totalTime = 3;

    public boolean setPower(int power) {
        byte[] setPower = new byte[8];
        setPower[0] = 0x0A;
        setPower[1] = (byte) 0xFF;
        setPower[2] = 0x05;
        setPower[3] = 0x23;
        setPower[4] = 0x6F;
        setPower[6] = (byte) power;
        setPower[7] = checkSum(setPower);
        try {
            mOutputStream.write(setPower);
            byte[] cache = new byte[5];
            Thread.sleep(20);
            mInputStream.read(cache);
            Log.w("setPower -- ", bytesToHexString(cache));
            String result = bytesToHexString(cache);
            if (result.equals("0000000000")) {
                if (repeatTime >= totalTime) {
                    return false;
                } else {
                    repeatTime++;
                    setPower(power);
                }
            } else if (result.substring(6, 8).equals("00")) {
                    repeatTime = 0;
                    return true;
            }
        } catch (IOException e) {
            e.printStackTrace();
            Log.e("error", e.toString());
        } catch (InterruptedException e) {
            e.printStackTrace();
            Log.e("error", e.toString());

        }
        return false;
    }

    /**
     * 十六进制转byte[]
     *
     * @param hex
     * @return
     */
    public byte[] hexTobytes(String hex) {
        byte[] bytes = new byte[hex.length() / 2];
        for (int i = 0; i < hex.length(); i = i + 2) {
            String subStr = hex.substring(i, i + 2);
            boolean flag = false;
            int intH = Integer.parseInt(subStr, 16);
            if (intH > 127) flag = true;
            if (intH == 128) {
                intH = -128;
            } else if (flag) {
                intH = 0 - (intH & 0x7F);
            }
            byte b = (byte) intH;
            bytes[i / 2] = b;
        }
        return bytes;
    }


    /**
     * Active Tags Inventory
     */
    public byte activeTagsInventory() {
        try {
            byte[] buffer = Tools.HexString2Bytes("0AFF029065");
            mOutputStream.write(buffer);
            byte[] cache = new byte[5];
            Thread.sleep(10);
            mInputStream.read(cache);
            return parseResponse(cache);
        } catch (Exception e) {
            Log.e("Huang", "ActiveTagsInventory >>>>>> " + "ERROR : \n" + e.getMessage());
            e.printStackTrace();
            return (byte) 0xFF;
        }
    }

    /**
     * Active Get Data
     */
    public List<byte[]> activeGetData() {
        try {
            byte[] buffer = Tools.HexString2Bytes("0AFF029A5B");
            mOutputStream.write(buffer);
            byte[] cache = new byte[1024];
            Thread.sleep(10);
            int len = mInputStream.read(cache);
            String response = Tools.Bytes2HexString(cache, len);
            Log.i("Huang", "activeGetData response : \n" + response);
            byte[] tags = new byte[len];
            System.arraycopy(cache, 0, tags, 0, len);
            return parseTagsData(tags);
        } catch (Exception e) {
            Log.e("Huang", "activeGetData >>>>>> " + "ERROR : \n" + e.getMessage());
            e.printStackTrace();
            return null;
        }
    }

    /**
     * Close RF
     * Stop TagsInventory
     */
    public byte deactiveTagsInventory() {
        try {
            byte[] buffer = Tools.HexString2Bytes("0AFF029164");
            mOutputStream.write(buffer);
            byte[] cache = new byte[5];
            Thread.sleep(10);
            mInputStream.read(cache);
            return parseResponse(cache);
        } catch (Exception e) {
            Log.e("Huang", "deactiveTagsInventory >>>>>> " + "ERROR : \n" + e.getMessage());
            e.printStackTrace();
            return (byte) 0xFF;
        }
    }

    /**
     * Parse command exec result from response bytes
     *
     * @param bytes response bytes
     * @return exec result
     */
    private byte parseResponse(byte[] bytes) {
        byte[] result = new byte[]{(byte) 0xFF};
        System.arraycopy(bytes, 3, result, 0, 1);
        return result[0];
    }

    /**
     * Parse tags data from response bytes
     *
     * @param data
     * @return
     */
    private List<byte[]> parseTagsData(byte[] data) {
        List<byte[]> tagList = new ArrayList<byte[]>();
        byte[] sizeByte = new byte[1];
        System.arraycopy(data, 4, sizeByte, 0, 1);
        Log.i("Huang", "parseTagsData >>>>>> sizeByte : \n" + sizeByte[0]);
        int size = sizeByte[0];
        for (int i = 0; i < size; i++) {
            byte[] tagByte = new byte[4];
            System.arraycopy(data, 6 + (10 * i), tagByte, 0, 4);
            tagList.add(tagByte);
        }
        return tagList;

    }

    private byte checkSum(byte[] data) {
        byte uSum = 0;
        for (int i = 0; i < data.length; i++) {
            uSum = (byte) (uSum + data[i]);
        }
        uSum = (byte) ((~uSum) + 1);
        return uSum;
    }

    public static String bytesToHexString(byte[] src) {
        StringBuilder stringBuilder = new StringBuilder("");
        if (src == null || src.length <= 0) {
            return null;
        }
        for (int i = 0; i < src.length; i++) {
            int v = src[i] & 0xFF;
            String hv = Integer.toHexString(v);
            if (hv.length() < 2) {
                stringBuilder.append(0);
            }
            stringBuilder.append(hv);
        }
        return stringBuilder.toString();
    }
}
