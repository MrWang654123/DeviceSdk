package com.luo.view;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.luo.materialsystem.R;

import java.util.List;

public class All_Adapter_Iuput extends BaseAdapter {

    private List<Module> list;
    private Context context;
    public All_Adapter_Iuput(List<Module> list1, Context context1){
        list =list1;
        context = context1;
    }
    public void setList(List<Module> list){
        this.list = list;
        notifyDataSetChanged();
    }
    @Override
    public int getCount() {
        return list.size();
    }

    @Override
    public Object getItem(int i) {
        return list.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        ViewHolder holder;
        if (view == null) {
            holder = new ViewHolder();
            view = LayoutInflater.from(context).inflate(R.layout.listview_item_input, null);
            holder.tv1 = (TextView) view.findViewById(R.id.tv_item_id);
            holder.tv2 = (TextView) view.findViewById(R.id.tv_item_data);
            holder.tv3 = (TextView) view.findViewById(R.id.tv_item_count);
            view.setTag(holder);
        }else{
            holder = (ViewHolder) view.getTag();
        }

        if (list != null && !list.isEmpty()) {
           holder.tv1.setText(list.get(i).getId());
           holder.tv2.setText(list.get(i).getData());
           holder.tv3.setText(list.get(i).getFlag());
        }
        return view;
    }

    private class ViewHolder {
        TextView tv1 ;
        TextView tv2 ;
        TextView tv3 ;
    }
}
