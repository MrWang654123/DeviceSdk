package com.luo.view;

public interface ToFragmentListener {
    void onDataListener(String data);
}